
Steps:

1. Create Kubernetes Cluster Through Terraform
   
   Follow File / PDF: STEPs for Kubernetes Cluster AKS through Terraform

   OR

   Through Azure Portal

   Follow PDF: Kubernetes Cluster through Azure Portal (Kubernetes Services)

2. Deploy Keycloak with Azure Postgresql Service 
 
   Create Azure Postgresql Service from Azure Portal & 

   Update appropiate values in values_azure.yaml 

   Examples:
   
    dbName: postgres
    dbHost: postgrek8s.postgres.database.azure.com
    dbPort: 5432
    dbUser: postgre@postgrek8s
    dbPassword: 12Thapril

   Follow File: Deploy_Keycloak_with_Azure_Postgre  

3. Deploy Nginx with HTTPS, Custom domain & LetsEncrypt

   Follow File / PDF : Steps to Deploy Nginx with HTTPS � LetsEncrypt TLS

4. AutoScale KeyCloak Statefulset:

   Follow File / PDF: Autoscale Keycloak Statefulset in Kubernetes

5. Autoscale Azure PostgreSQL Servicce 

   Follow File / PDF: Autoscale azure postgre service database

6. Cleanup cluster

   Follow Link: https://docs.microsoft.com/en-us/rest/api/aks/managedclusters/delete



